---
title: 说说
date: 2020-10-17 01:48:17
type: "artitalk"
top_img: /img/pic/link.png
aside: false
layout: "artitalk"
---

<script type="text/javascript" src="https://cdn.jsdelivr.net/gh/yanhuacuo/JS@1.0/artitalk.js"></script>
<div id="artitalk_main"></div>
<script>
new Artitalk({
    appId: "lwStDG2fjuyFhuyayYrkGSLl-MdYXbMMI",
    appKey: "5c8xkKjzae2VRL8ijI54L4Bc",
    avatarPla: "https://7.dusays.com/2021/02/14/6eac515f6a5aa.jpg",
    pageSize: 50
})
</script>