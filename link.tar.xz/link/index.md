---
title: 友情链接
date: 2020-02-02 10:00:00
type: "link"
top_img: /img/pic/light.jpg
aside: false
layout: "link"
---

<script src='/js/friend.min.js'></script>

<script>
if(typeof(Friend)=='undefined'){
  location.href='/link'
}
  document.querySelector('.flink').insertAdjacentHTML('afterbegin',"<div id='friend1'></div>")
  var obj = {
    el: '#friend1',
    owner: 'wubi98',
    repo: 'wubi98',
    direction_sort: 'asc',
    sort_container: ["我的站点"],
    labelDescr: {
      大佬们: "<span style='color:red;'>这是一群大佬哦！</span>",
      菜鸡们: "<span style='color:red;'>这是一群菜鸡哦！</span>"
    },
    fail_img: ''
  }
    document.querySelector('.flink').insertAdjacentHTML('afterbegin',"<div id='friend1'></div>")
    new Friend(obj)
</script>


# 交换友链

## 途径

需要交换友链的朋友，请到 [这里](https://gitee.com/wubi98/wubi98/issues) 比照着已经存在的 [issues](https://gitee.com/wubi98/wubi98/issues) 递交的 **issues** ，小筑管理员给您分配标签后即会生效。

## 要求

- 您的网站一年内有更新
- 请您提前添加本站友链
- 贵站内容不涉非法内容

## 求助

如果您不太清楚 issues 提交方式，或没有 gitee 帐号，在满足要求的前提下，可以在评论中留下网址。
